from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
from .api import router
from .db import init_db

app = FastAPI(title="Dyad App v1")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)
app.include_router(router)


@app.on_event("startup")
def startup():
    init_db()


# DEPLOY: serve the built frontend from the same origin when present.
# Mounted after the API router so /turn, /heat, etc. take precedence.
_DIST = os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "dist")
if os.path.isdir(_DIST):
    app.mount("/", StaticFiles(directory=_DIST, html=True), name="static")
