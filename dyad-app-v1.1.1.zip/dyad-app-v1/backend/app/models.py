from pydantic import BaseModel, Field
from typing import Optional, List
import uuid


class HeatReset(BaseModel):
    at: str
    snapshot_ref: str
    trigger: str


class StructuralTruth(BaseModel):
    version: int
    text: str
    established_at: str


class OpenThread(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    label: str
    status: str = "OPEN"


class FrictionEntry(BaseModel):
    entry_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    turn_index: int
    at: str
    trigger: str
    resolution: str
    status: str = "ACTIVE"


class GraceEntry(BaseModel):
    entry_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    turn_index: int
    at: str
    content: str
    context: str
    marked_by: str
    status: str = "ACTIVE"


class ModeOverride(BaseModel):
    active: bool = False
    overridden_from: Optional[str] = None
    override_count: int = 0


class Wireframe(BaseModel):
    session_id: str
    generation: int = 0
    turn_index: int = 0
    turns_since_summary: int = 0
    mode: str = "DEEP"
    mode_override: ModeOverride = Field(default_factory=ModeOverride)
    structural_truth: List[StructuralTruth] = []
    open_threads: List[OpenThread] = []
    friction_log: List[FrictionEntry] = []
    grace_log: List[GraceEntry] = []
    loop_history: List[str] = []
    recent_turns: List[dict] = []
    heat_resets: List[HeatReset] = []


class Payload1Payload(BaseModel):
    text: str
    mode_override: Optional[str] = None


class Payload1(BaseModel):
    session_id: str
    user_id: str
    client_sent_at: str
    client_request_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    expected_generation: int = 0
    payload: Payload1Payload


class Payload4(BaseModel):
    message_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    backend_processed_at: str
    dropped: bool = False
    payload: dict
