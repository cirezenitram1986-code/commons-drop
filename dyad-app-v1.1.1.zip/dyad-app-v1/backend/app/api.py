from fastapi import APIRouter
from datetime import datetime, timezone
from .state_machine import process_turn, execute_heat, execute_dispute, execute_rollback
from .models import Payload1, GraceEntry
from .db import get_db, load_wireframe, save_wireframe, atomic_transaction

router = APIRouter()


@router.post("/turn")
def turn(p1: Payload1):
    db = get_db()
    try:
        # WREN/ROOK FIX: wrap in atomic_transaction so state actually commits.
        # Without this, closing the connection rolled back every turn's writes —
        # a silent total persistence failure the single-connection tests masked.
        with atomic_transaction(db):
            result = process_turn(db, p1)
        return result
    finally:
        db.close()


@router.post("/heat")
def heat(request: dict):
    db = get_db()
    try:
        with atomic_transaction(db):
            new_gen = execute_heat(db, request["session_id"], request.get("trigger", "manual"))
        return {"generation": new_gen}
    finally:
        db.close()


@router.post("/dispute")
def dispute(request: dict):
    db = get_db()
    try:
        with atomic_transaction(db):
            execute_dispute(db, request["session_id"], request["friction_id"])
        return {"status": "disputed"}
    finally:
        db.close()


@router.post("/rollback")
def rollback(request: dict):
    db = get_db()
    try:
        with atomic_transaction(db):
            new_gen = execute_rollback(db, request["session_id"], request["target_version"])
        return {"generation": new_gen}
    finally:
        db.close()


@router.post("/grace")
def log_grace(request: dict):
    db = get_db()
    try:
        with atomic_transaction(db):
            wf = load_wireframe(db, request["session_id"])
            new_entry = GraceEntry(
                turn_index=request["turn_index"],
                at=datetime.now(timezone.utc).isoformat(),
                content=request["content"],
                context=request["context"],
                marked_by=request["marked_by"],
                status="ACTIVE",
            )
            wf.grace_log.append(new_entry)
            save_wireframe(db, wf)
        return {"status": "logged", "entry_id": new_entry.entry_id}
    finally:
        db.close()


@router.post("/grace/status")
def update_grace_status(request: dict):
    db = get_db()
    try:
        with atomic_transaction(db):
            wf = load_wireframe(db, request["session_id"])
            for g in wf.grace_log:
                if g.entry_id == request["entry_id"]:
                    g.status = request["status"]
                    break
            save_wireframe(db, wf)
        return {"status": "updated"}
    finally:
        db.close()
