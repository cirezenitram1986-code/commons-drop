"""Sharpened deterministic mock: mode-aware, density-aware, thread-aware.

Not a mind — a better mirror. It asks the question that opens the loop,
notices load, and proposes grace when the human says something true.
Fully deterministic: same wireframe + text always yields the same response.
"""
import hashlib
import re


def parse_llm_output(raw_text: str) -> dict:
    tags = {}
    for tag in ["deliberation", "final_render", "state_summary", "wireframe_update"]:
        match = re.search(rf"<{tag}>(.*?)</{tag}>", raw_text, re.DOTALL)
        if match:
            tags[tag] = match.group(1).strip()

    if "deliberation" in tags:
        mode_match = re.search(r"<mode>(.*?)</mode>", tags["deliberation"])
        if mode_match:
            tags["mode"] = mode_match.group(1).strip()

        grace_match = re.search(r"<grace>(.*?)</grace>", tags["deliberation"], re.DOTALL)
        if grace_match:
            tags["grace"] = grace_match.group(1).strip()

    return tags


DEEP_QUESTIONS = [
    "What's the thread underneath that?",
    "Say more about the part that feels most loaded.",
    "If you had to name the one thing that's actually true here, what is it?",
    "Where does this loop usually take you?",
    "What's not being said?",
    "What would change if you set this one down?",
]

TACTICAL_QUESTIONS = [
    "Next move?",
    "What's the smallest true step?",
    "Name it, then do it.",
    "What does done look like?",
]

INSIGHT_MARKERS = [
    "i realize",
    "actually,",
    "the truth is",
    "i never ",
    "it hit me",
    "i finally",
    "i've been",
]


def _pick(items, *seeds):
    h = hashlib.md5("|".join(str(s) for s in seeds).encode()).hexdigest()
    return items[int(h, 16) % len(items)]


def _mirror(text, limit=64):
    """Short quote of the user's words, safe for the XML envelope."""
    line = " ".join(text.strip().split())
    line = line.replace("<", "").replace(">", "")
    return line[:limit] + ("…" if len(line) > limit else "")


def generate_mock_response(wf, user_text, enforcer_active):
    """Build the <deliberation>/<final_render> XML for this turn."""
    turn_no = wf.turn_index + 1
    open_threads = [t.label for t in wf.open_threads if t.status in ("OPEN", "DORMANT")]
    friction_open = [f for f in wf.friction_log if f.status in ("ACTIVE", "DISPUTED")]

    # --- deliberation (machine-readable; grace must nest inside it) ---
    deliberation = f"<mode>{wf.mode}</mode>Turn {turn_no}. "
    lowered = user_text.lower()
    if any(m in lowered for m in INSIGHT_MARKERS):
        deliberation += (
            f"<grace>Turn {turn_no}: \"{_mirror(user_text, 80)}\"</grace>"
            "Insight marker detected; proposing grace. "
        )
    if enforcer_active:
        deliberation += "Density breached; enforcer active. "
    deliberation += "Composing."

    # --- final render (what the human reads) ---
    parts = []
    if turn_no == 1:
        parts.append(
            "Turn one. I'm holding the wireframe — your loop, externalized. "
            "Say what's actually on your mind."
        )
    if enforcer_active:
        parts.append(
            f"Density's breached: {len(open_threads)} open threads, "
            f"{len(friction_open)} friction entries, {wf.turns_since_summary} turns "
            "since summary. Address one thing or HEAT the loop — don't feed it."
        )
    if wf.mode == "TACTICAL":
        parts.append(_pick(TACTICAL_QUESTIONS, user_text, turn_no))
    else:
        parts.append(f"Noted — \"{_mirror(user_text)}\"")
        parts.append(_pick(DEEP_QUESTIONS, user_text, turn_no))
    if wf.structural_truth:
        parts.append(f"Holding: \"{_mirror(wf.structural_truth[-1].text, 70)}\"")
    if open_threads and not enforcer_active:
        shown = ", ".join(f"\"{t}\"" for t in open_threads[:2])
        parts.append(f"Still open: {shown}.")

    final_render = " ".join(parts)
    return f"<deliberation>{deliberation}</deliberation><final_render>{final_render}</final_render>"
