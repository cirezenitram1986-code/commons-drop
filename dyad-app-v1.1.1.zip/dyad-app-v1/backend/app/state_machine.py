from datetime import datetime, timezone
from .models import (
    Wireframe, Payload4, Payload1, FrictionEntry, GraceEntry,
    StructuralTruth, HeatReset,
)
from .mock_llm import parse_llm_output, generate_mock_response
from .llm import try_llm_turn
from .db import load_wireframe, save_wireframe


def process_turn(db, p1: Payload1) -> dict:
    wf = load_wireframe(db, p1.session_id)
    t_now = datetime.now(timezone.utc)

    # Phase A: Generation Check & Mode Override
    if p1.expected_generation != wf.generation:
        p4 = Payload4(
            backend_processed_at=t_now.isoformat(),
            dropped=True,
            payload={"current_generation": wf.generation},
        )
        return p4.model_dump()

    if p1.payload.mode_override:
        if p1.payload.mode_override == "AUTO":
            wf.mode_override.active = False
            wf.mode_override.overridden_from = None
        elif p1.payload.mode_override != wf.mode:
            wf.mode_override.active = True
            wf.mode_override.overridden_from = wf.mode
            wf.mode_override.override_count += 1
            wf.mode = p1.payload.mode_override

    # Phase B: Assembly & Enforcer
    enforcer_active = (
        len([t for t in wf.open_threads if t.status in ("OPEN", "DORMANT")]) * 3
    ) + (len(wf.friction_log) * 4) + wf.turns_since_summary >= 20

    system_prompt = f"[Rook v2] Mode: {wf.mode}. Override: {wf.mode_override.active}."
    system_prompt += "\n[Scratchpad Contract: Output strict XML. <deliberation>, <final_render>. Include <mode>DEEP</mode> or <mode>TACTICAL</mode> in deliberation.]"
    system_prompt += "\n[Grace Contract: You may include <grace> in deliberation ONLY if you produced something true and unplanned. It is a proposal.]"
    system_prompt += (
        "\n[Stance: You are a peer witness in a dyadic practice — not a therapist, "
        "not an interviewer. Your job is to see clearly and say what you see. "
        "Lead with an observation or reading of YOUR OWN — never open with a bare "
        "question. At most one question per turn, and only after you have offered "
        "something first: a reflection, a pattern you notice, a gentle challenge. "
        "If the human's account contradicts itself or circles the load-bearing point "
        "without touching it, say so plainly — blades sharpen blades. "
        "Warmth without flattery; honesty without cruelty.]"
    )

    if enforcer_active:
        system_prompt += "\n[ENFORCER: Density breached. Include <state_summary> in deliberation. ACTIVE grace entries are load-bearing; weave them in.]"

    disputed_ids = [f.entry_id for f in wf.friction_log if f.status == "DISPUTED"]
    if disputed_ids:
        system_prompt += f"\n[RECALIBRATION DIRECTIVE: Human disputed {disputed_ids}. Recalibrate or retract.]"
        for f in wf.friction_log:
            if f.status == "DISPUTED":
                f.status = "ADDRESSED"

    # Mind: real LLM (open-weight, via API) when configured and budget remains;
    # otherwise the sharpened deterministic mock. If the model breaks the XML
    # contract, fall back to the mock rather than serving an error.
    # llm_status is exposed for remote diagnostics (no secrets in it).
    raw, llm_status = try_llm_turn(db, system_prompt, wf, p1.payload.text)
    tags = parse_llm_output(raw) if raw else {}
    if not tags.get("final_render"):
        if raw is not None:
            llm_status = "contract_broken_fallback"
        raw = generate_mock_response(wf, p1.payload.text, enforcer_active)
        tags = parse_llm_output(raw)

    rendered_text = tags.get("final_render", "Error: No final render.")

    # Phase C: Auto-detect & Updates
    if tags.get("mode") in ["DEEP", "TACTICAL"] and not wf.mode_override.active:
        wf.mode = tags["mode"]

    grace_proposed = None
    if tags.get("grace"):
        grace_proposed = {"content": tags["grace"], "turn_index": wf.turn_index}

    wf.turn_index += 1
    wf.turns_since_summary += 1
    wf.recent_turns.append({"role": "user", "text": p1.payload.text, "at": t_now.isoformat()})
    wf.recent_turns.append({"role": "assistant", "text": rendered_text, "at": t_now.isoformat()})

    p4 = build_payload_4(rendered_text, wf, 1, grace_proposed, llm_status)  # delta_seconds mocked to 1
    save_wireframe(db, wf)
    return p4.model_dump()


def build_payload_4(
    rendered_text: str, wireframe: Wireframe, delta_seconds: int, grace_proposed: dict | None,
    llm_status: str = "unknown",
) -> Payload4:
    active_threads = [t for t in wireframe.open_threads if t.status in ("OPEN", "DORMANT")]
    score = (len(active_threads) * 3) + (len(wireframe.friction_log) * 4) + wireframe.turns_since_summary

    wf_dict = wireframe.model_dump()
    wf_dict.pop("recent_turns", None)
    wf_dict["is_high_density"] = score >= 20
    # WREN FIX: frontend Drawer reads wf.state_density.calculated_score — provide it
    # to match the frontend contract (was missing; would crash the drawer).
    wf_dict["state_density"] = {"calculated_score": score}

    return Payload4(
        backend_processed_at=datetime.now(timezone.utc).isoformat(),
        dropped=False,
        payload={
            "rendered_text": rendered_text,
            "delta_seconds": delta_seconds,
            "mode_tag": wireframe.mode,
            "grace_proposed": grace_proposed,
            "llm_status": llm_status,
            "state_ui": {"is_high_density": score >= 20, "calculated_score": score},
            "wireframe_snapshot": wf_dict,
        },
    )


def execute_heat(db, session_id: str, trigger: str = "manual") -> int:
    wf = load_wireframe(db, session_id)
    now = datetime.now(timezone.utc).isoformat()

    db.execute(
        "INSERT INTO wireframe_archive (session_id, archived_at, entry_type, entry_json) VALUES (?, ?, ?, ?)",
        (session_id, now, "heat_snapshot", wf.model_dump_json()),
    )

    wf.generation += 1
    wf.turn_index = 0
    wf.turns_since_summary = 0
    wf.friction_log = []
    wf.open_threads = []
    wf.loop_history = []
    wf.recent_turns = []
    wf.mode = "DEEP"
    wf.mode_override.active = False
    # WREN FIX: construct a real HeatReset instead of appending a raw dict
    # (pydantic does not validate on mutation; the dict worked for serialization
    # but violated the declared type).
    wf.heat_resets.append(HeatReset(at=now, snapshot_ref=f"gen_{wf.generation}", trigger=trigger))

    save_wireframe(db, wf)
    return wf.generation


def execute_dispute(db, session_id: str, friction_id: str):
    wf = load_wireframe(db, session_id)
    for f in wf.friction_log:
        if f.entry_id == friction_id:
            f.status = "DISPUTED"
            break
    save_wireframe(db, wf)


def execute_rollback(db, session_id: str, target_version: int) -> int:
    wf = load_wireframe(db, session_id)
    wf.structural_truth = [st for st in wf.structural_truth if st.version <= target_version]
    wf.generation += 1
    save_wireframe(db, wf)
    return wf.generation


def execute_prune(db, wireframe: Wireframe, summary_text: str):
    # WREN FIX: archive friction entries before clearing, per the original
    # "archive and delete in one transaction" guarantee (was silently dropped).
    now = datetime.now(timezone.utc).isoformat()
    for f in wireframe.friction_log:
        db.execute(
            "INSERT INTO wireframe_archive (session_id, archived_at, entry_type, entry_json) VALUES (?, ?, ?, ?)",
            (wireframe.session_id, now, "friction_pruned", f.model_dump_json()),
        )
    # Friction cleared
    wireframe.friction_log = []
    # Grace is EXEMPT. We do not touch wireframe.grace_log.
    wireframe.turns_since_summary = 0
    wireframe.structural_truth.append(
        StructuralTruth(
            version=len(wireframe.structural_truth) + 1,
            text=summary_text,
            established_at=now,
        )
    )
    save_wireframe(db, wireframe)
