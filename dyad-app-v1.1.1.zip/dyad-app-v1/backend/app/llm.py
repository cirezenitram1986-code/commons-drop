"""Real-mind adapter: OpenAI-compatible chat API serving open-weight models.

No key configured -> None (caller falls back to the sharpened mock).
A daily budget guards the key against public-traffic abuse.
Provider-agnostic: point LLM_BASE_URL / LLM_MODEL at any OpenAI-compatible
endpoint. Defaults: Groq free tier, open-weight Llama.
"""
import json
import os
import urllib.request
from datetime import date


def _cfg():
    return {
        "api_key": os.environ.get("LLM_API_KEY", "").strip(),
        "base_url": os.environ.get("LLM_BASE_URL", "https://api.groq.com/openai/v1").rstrip("/"),
        "model": os.environ.get("LLM_MODEL", "llama-3.3-70b-versatile"),
        "daily_budget": int(os.environ.get("LLM_DAILY_BUDGET", "200")),
        "timeout": float(os.environ.get("LLM_TIMEOUT_S", "30")),
    }


def _budget_ok(db, budget):
    today = date.today().isoformat()
    row = db.execute("SELECT count FROM llm_budget WHERE day=?", (today,)).fetchone()
    return (row["count"] if row else 0) < budget


def _budget_consume(db):
    today = date.today().isoformat()
    db.execute(
        "INSERT INTO llm_budget (day, count) VALUES (?, 1) "
        "ON CONFLICT(day) DO UPDATE SET count = count + 1",
        (today,),
    )
    db.commit()


def _history_block(wf, n=6):
    turns = wf.recent_turns[-n:] if wf.recent_turns else []
    if not turns:
        return ""
    lines = ["[Conversation so far]"]
    for t in turns:
        role = t.get("role", "?")
        text = str(t.get("text", ""))[:300]
        lines.append(f"{role}: {text}")
    return "\n".join(lines) + "\n"


def try_llm_turn(db, system_prompt, wf, user_text):
    """Returns (raw_text_or_None, status). Status is machine-readable for diagnostics."""
    cfg = _cfg()
    if not cfg["api_key"]:
        return None, "disabled_no_key"
    if not _budget_ok(db, cfg["daily_budget"]):
        return None, "budget_exhausted"

    full_system = system_prompt + "\nOutput ONLY the XML, no prose outside the tags."
    history = _history_block(wf)
    body = {
        "model": cfg["model"],
        "temperature": 0.7,
        "max_tokens": 600,
        "messages": [
            {"role": "system", "content": full_system},
            {
                "role": "user",
                "content": (history + "user: " + user_text) if history else user_text,
            },
        ],
    }
    req = urllib.request.Request(
        cfg["base_url"] + "/chat/completions",
        data=json.dumps(body).encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {cfg['api_key']}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=cfg["timeout"]) as resp:
            data = json.load(resp)
        content = data["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        return None, f"http_{e.code}"
    except Exception as e:
        return None, f"exception_{type(e).__name__}"
    if not content or not content.strip():
        return None, "empty_response"
    _budget_consume(db)
    return content, "ok"
