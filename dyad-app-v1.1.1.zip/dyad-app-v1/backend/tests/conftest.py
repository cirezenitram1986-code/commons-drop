import pytest
import os
from app.db import init_db, get_db
from app.models import Wireframe


@pytest.fixture
def db():
    import app.db as db_module

    db_module.DB_PATH = "test_dyad_state.db"
    if os.path.exists("test_dyad_state.db"):
        os.remove("test_dyad_state.db")
    init_db()
    conn = get_db()
    yield conn
    conn.close()
    if os.path.exists("test_dyad_state.db"):
        os.remove("test_dyad_state.db")


@pytest.fixture
def sample_wireframe():
    return Wireframe(session_id="test-session")
