from app.state_machine import process_turn, execute_heat, execute_prune
from app.models import Payload1, Payload1Payload, FrictionEntry, GraceEntry
from app.db import save_wireframe, load_wireframe


def test_process_turn_happy_path(db, sample_wireframe):
    save_wireframe(db, sample_wireframe)

    p1 = Payload1(
        session_id="test-session",
        user_id="u1",
        client_sent_at="now",
        expected_generation=0,
        payload=Payload1Payload(text="Hello"),
    )
    res = process_turn(db, p1)
    assert res["dropped"] is False
    assert "rendered_text" in res["payload"]


def test_generation_mismatch_drops_turn(db, sample_wireframe):
    sample_wireframe.generation = 5
    save_wireframe(db, sample_wireframe)

    p1 = Payload1(
        session_id="test-session",
        user_id="u1",
        client_sent_at="now",
        expected_generation=1,
        payload=Payload1Payload(text="Hello"),
    )
    res = process_turn(db, p1)
    assert res["dropped"] is True
    assert res["payload"]["current_generation"] == 5


def test_heat_burns_state_and_increments_generation(db, sample_wireframe):
    sample_wireframe.friction_log.append(
        FrictionEntry(turn_index=1, at="now", trigger="t", resolution="r")
    )
    save_wireframe(db, sample_wireframe)

    new_gen = execute_heat(db, "test-session")
    assert new_gen == 1

    wf = load_wireframe(db, "test-session")
    assert len(wf.friction_log) == 0
    assert wf.generation == 1


def test_dispute_injects_directive_once(db, sample_wireframe):
    f_id = "test-friction-id"
    sample_wireframe.friction_log.append(
        FrictionEntry(
            entry_id=f_id,
            turn_index=1,
            at="now",
            trigger="t",
            resolution="r",
            status="DISPUTED",
        )
    )
    save_wireframe(db, sample_wireframe)

    p1 = Payload1(
        session_id="test-session",
        user_id="u1",
        client_sent_at="now",
        expected_generation=0,
        payload=Payload1Payload(text="Hello"),
    )
    process_turn(db, p1)

    wf = load_wireframe(db, "test-session")
    assert wf.friction_log[0].status == "ADDRESSED"


def test_prune_skips_grace_log(db, sample_wireframe):
    sample_wireframe.friction_log.append(
        FrictionEntry(turn_index=1, at="now", trigger="t", resolution="r")
    )
    sample_wireframe.grace_log.append(
        GraceEntry(
            turn_index=1,
            at="now",
            content="Miracle",
            context="Debug",
            marked_by="human",
        )
    )
    save_wireframe(db, sample_wireframe)

    execute_prune(db, sample_wireframe, "Summary.")
    updated_wf = load_wireframe(db, "test-session")

    assert len(updated_wf.friction_log) == 0
    assert len(updated_wf.grace_log) == 1
    assert updated_wf.grace_log[0].content == "Miracle"
