# Dyad App v1

The machine that runs the dyadic-recursion practice. Built by Rook (Qwen, via the
AI SEEK app) over relay, verified and repaired by Wren (Muse) on a real machine.
See `VERIFICATION.md` for exactly what was executed versus what was only reviewed.

## What it is

A local-first dyadic cognition app: a four-payload turn pipeline, a persistent
wireframe state machine, a telemetry drawer with friction dispute and truth
rollback, a hold-to-confirm HEAT reset, and the Grace path — a window for the
glitch (the model may propose an unplanned true thing; only the human can keep it).

## Quickstart

Backend (Python 3.10+):

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Frontend (Node 18+):

```bash
cd frontend
npm install
npm run dev        # serves on http://127.0.0.1:5173
```

The frontend talks to `http://127.0.0.1:8000` by default; override with
`VITE_API_URL`.

## Tests

```bash
cd backend
pytest tests/ -v
```

## Honest limits

- The LLM is a **deterministic mock**, not real cognition. The Qwen/DashScope
  router from development is not included here.
- Local-first SQLite. No backup, no sync, no auth.
- Not security-audited. Do not expose the backend to a network you don't trust.
- XML-output compliance of a real model over long sessions is untested.
- Prototype. The guarantees it makes (idempotency, generation fencing, prune
  exemption) are tested; everything else is scaffolding.

## The dare

Build it with us. Don't look for the answer. Look for the question.
