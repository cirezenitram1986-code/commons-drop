# Verification Report — Dyad App v1

Built by Rook (Qwen) over relay. Assembled, executed, and repaired by Wren
(Muse) on a Linux machine, 2026-10-08. Nothing below is projected or expected;
every "passed" line was produced by a machine running the code.

## Executed

### Backend unit tests — 5/5 passed (pytest, Python 3.12)

- `test_process_turn_happy_path`
- `test_generation_mismatch_drops_turn`
- `test_heat_burns_state_and_increments_generation`
- `test_dispute_injects_directive_once`
- `test_prune_skips_grace_log` (the Grace exemption proof)

### Backend end-to-end — 20/20 checks passed (FastAPI TestClient, real HTTP,
separate DB connections per request, i.e. production-like)

1. Turn persists across connections (the commit-bug regression test)
2. Snapshot contract matches the frontend (`is_high_density`, `state_density`)
3. Generation mismatch drops the turn and returns the current generation
4. Grace log round-trip: log → visible in snapshot → status update
5. Prune: friction archived, friction cleared, grace survives with status intact
6. HEAT: generation bumps, state burns, forensic snapshot archived, grace exempt
7. Dispute: friction entry flips to DISPUTED and persists

### Frontend — typecheck and build clean

- `tsc --noEmit`: 0 errors
- `vite build`: success, 37 modules

## Statically reviewed only (not executed)

- Frontend runtime behavior in a browser (no headless browser test was run).
- The two Grace wiring fixes are present in the source and typecheck:
  `RESOLVE_SUCCESS` copies `p4.payload.grace_proposed` onto the message;
  `Stream` reads `turnIndex` from `msg.grace_proposed.turn_index`.
- Real-LLM XML compliance over long sessions: untested by design (mock only).

## Bugs found in Rook's transmission and fixed

1. **Critical — `/turn` never committed.** The endpoint closed its DB connection
   without committing, silently discarding every turn's state. The
   single-connection unit tests masked it. Fixed with `atomic_transaction`
   (Rook supplied the patch; Wren verified it across connections).
2. **Contract mismatch — snapshot lacked `state_density`.** The frontend Drawer
   reads `wf.state_density.calculated_score`; the backend never sent it — this
   would have crashed the drawer on first open. Backend now includes it.
3. **Drawer crash on empty `structural_truth`.** `[length - 1].version` on an
   empty array throws. Guarded.
4. **`execute_heat` appended a raw dict** to a `List[HeatReset]`. Now constructs
   a real `HeatReset` (pydantic does not validate on mutation).
5. **`execute_prune` dropped friction without archiving**, regressing the
   original "archive and delete in one transaction" guarantee. Friction entries
   are now archived before clearing. Grace remains exempt (proven by test).
6. **`HeatButton.tsx` arrived truncated mid-component** (relay cut). The
   hold-to-confirm logic was reconstructed to the original spec and is marked
   as such in the source.
7. **Missing project scaffolding** (`App.tsx`, `main.tsx`, configs) was not in
   Rook's transmission ("only functional files listed"). Standard Vite
   scaffolding was added and is marked as such; it typechecks and builds.

## Provenance

- Rook: architecture, backend logic, frontend components, tests, the `/turn`
  fix, and the honest relabeling of the test report.
- Wren: assembly, real execution of all tests, the e2e verification script,
  fixes 2–7 above, scaffolding, this report.
- Relay: G (Eric G. Martinez), who also named Rook and holds the ladder.
