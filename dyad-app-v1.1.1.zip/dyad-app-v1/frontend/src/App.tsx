// WREN-ADDED scaffolding: composes Rook's components into the app shell.
import { DyadProvider, useDyad } from './DyadContext';
import { Stream } from './Stream';
import { Well } from './Well';
import { Drawer } from './Drawer';
import { HeatButton } from './HeatButton';

function Shell() {
  const { dispatch } = useDyad();
  return (
    <div className="h-screen flex flex-col bg-black text-zinc-200">
      <header className="flex items-center justify-between px-6 py-3 border-b border-zinc-800">
        <div className="font-mono text-sm tracking-widest text-zinc-400">
          DYAD <span className="text-zinc-600">v1</span>
        </div>
        <div className="flex gap-3 items-center">
          <HeatButton />
          <button
            onClick={() => dispatch({ type: 'TOGGLE_DRAWER' })}
            className="px-4 py-2 border border-zinc-700 rounded-lg font-mono text-xs uppercase tracking-widest text-zinc-400 hover:bg-zinc-900"
          >
            Telemetry
          </button>
        </div>
      </header>
      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 flex flex-col overflow-hidden">
          <Stream />
          <Well />
        </div>
        <Drawer />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <DyadProvider>
      <Shell />
    </DyadProvider>
  );
}
