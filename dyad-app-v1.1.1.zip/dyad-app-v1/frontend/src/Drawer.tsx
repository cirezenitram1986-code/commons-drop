import { useDyad } from './DyadContext';

export function Drawer() {
  const { state, dispatch, handleDispute, handleRollback, handleUpdateGraceStatus } = useDyad();
  const wf = state.wireframe;

  return (
    <div className={`h-full bg-zinc-950 border-l border-zinc-800 flex flex-col transition-all duration-300 ${state.isDrawerOpen ? 'w-80' : 'w-0 overflow-hidden'}`}>
      <div className="p-4 border-b border-zinc-800 flex justify-between items-center">
        <h2 className="text-zinc-300 font-mono text-sm uppercase tracking-wider">Telemetry</h2>
        <button onClick={() => dispatch({ type: 'TOGGLE_DRAWER' })} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 text-sm">
        {!wf ? (
          <div className="text-zinc-600 font-mono text-xs">Awaiting first turn...</div>
        ) : (
          <>
            <section>
              <h3 className="text-zinc-500 font-mono text-xs uppercase mb-2">State</h3>
              <div className="grid grid-cols-2 gap-2 text-zinc-400 font-mono text-xs">
                <div>Gen: <span className="text-zinc-200">{wf.generation}</span></div>
                <div>Turn: <span className="text-zinc-200">{wf.turn_index}</span></div>
                <div className="col-span-2 flex justify-between items-center">
                  <span>Mode: <span className="text-emerald-400">{wf.mode}</span></span>
                  <span className={`text-[10px] ${wf.mode_override.active ? 'text-amber-400' : 'text-zinc-600'}`}>{wf.mode_override.active ? '(Manual)' : '(Auto)'}</span>
                </div>
                <div>Score: <span className={wf.state_density.calculated_score >= 20 ? 'text-amber-400' : 'text-zinc-200'}>{wf.state_density.calculated_score}</span></div>
              </div>
            </section>

            <section>
              <h3 className="text-zinc-500 font-mono text-xs uppercase mb-2">Structural Truth</h3>
              <div className="space-y-3">
                {wf.structural_truth.slice().reverse().map((st) => (
                  <div key={st.version} className="border-l-2 border-zinc-700 pl-3 py-1 group relative">
                    <p className="text-zinc-300 text-xs leading-relaxed italic">{st.text}</p>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-zinc-600 text-[10px]">v{st.version}</span>
                      {/* WREN FIX: guard against empty structural_truth (would throw on [length-1].version) */}
                      {wf.structural_truth.length > 0 && st.version < wf.structural_truth[wf.structural_truth.length - 1].version && (
                        <button onClick={() => handleRollback(st.version)} className="text-[10px] text-red-500/50 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">ROLLBACK</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h3 className="text-zinc-500 font-mono text-xs uppercase mb-2">Friction Log ({wf.friction_log.length})</h3>
              <ul className="space-y-2">
                {wf.friction_log.slice(-5).reverse().map(f => (
                  <li key={f.entry_id} className={`text-xs border rounded p-2 ${f.status === 'DISPUTED' ? 'border-red-500/50 bg-red-500/5' : 'border-zinc-800'}`}>
                    <div className="text-zinc-500">Trigger: <span className="text-zinc-300">{f.trigger}</span></div>
                    <div className="text-zinc-500 mt-1">Resolution: <span className="text-zinc-300">{f.resolution}</span></div>
                    {f.status === 'ACTIVE' && <button onClick={() => handleDispute(f.entry_id)} className="mt-2 text-[10px] text-amber-500 hover:text-amber-400 font-mono uppercase tracking-wider">Dispute</button>}
                    {f.status === 'DISPUTED' && <div className="mt-2 text-[10px] text-red-400 font-mono uppercase tracking-wider">Disputed</div>}
                  </li>
                ))}
              </ul>
            </section>

            <section>
              <h3 className="text-teal-500/80 font-mono text-xs uppercase mb-2 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-teal-500/80 rounded-full"></span>
                Grace ({wf.grace_log.length})
              </h3>
              {wf.grace_log.length === 0 ? (
                <div className="text-zinc-600 text-xs italic">No moments preserved.</div>
              ) : (
                <ul className="space-y-3">
                  {wf.grace_log.slice().reverse().map(g => (
                    <li key={g.entry_id} className={`text-xs border rounded p-3 transition-colors ${g.status === 'INTEGRATED' ? 'border-teal-500/40 bg-teal-950/20' : g.status === 'DISPUTED' ? 'border-red-500/30 bg-red-950/10' : 'border-teal-500/20 bg-zinc-900/50'}`}>
                      <div className="text-teal-200/90 leading-relaxed mb-2">{g.content}</div>
                      <div className="text-zinc-500 text-[10px] mb-2">Context: {g.context}</div>
                      <div className="flex justify-between items-center mt-2 pt-2 border-t border-zinc-800/50">
                        <span className="text-[10px] text-zinc-600 uppercase">{g.marked_by === 'human' ? 'Human' : 'Node'} • {g.status}</span>
                        <div className="flex gap-3">
                          {g.status === 'ACTIVE' && (
                            <>
                              <button onClick={() => handleUpdateGraceStatus(g.entry_id, 'INTEGRATED')} className="text-[10px] text-teal-400 hover:text-teal-300 font-mono uppercase">Integrate</button>
                              <button onClick={() => handleUpdateGraceStatus(g.entry_id, 'DISPUTED')} className="text-[10px] text-red-400/70 hover:text-red-400 font-mono uppercase">Dispute</button>
                            </>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </div>
    </div>
  );
}
