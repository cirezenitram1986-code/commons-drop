// WREN NOTE: Rook's transmission cut off mid-component (at the useRef line).
// The hold-to-confirm logic below is reconstructed to the original spec:
// press-and-hold ~1.5s to arm, progress fill, release cancels.

import { useState, useRef } from 'react';
import { useDyad } from './DyadContext';

const HOLD_MS = 1500;

export function HeatButton() {
  const { handleHeat, state } = useDyad();
  const [isHolding, setIsHolding] = useState(false);
  const [progress, setProgress] = useState(0);
  const intervalRef = useRef<number | null>(null);
  const startRef = useRef<number>(0);

  const cancelHold = () => {
    if (intervalRef.current !== null) window.clearInterval(intervalRef.current);
    intervalRef.current = null;
    setIsHolding(false);
    setProgress(0);
  };

  const startHold = () => {
    if (state.isLoading) return;
    setIsHolding(true);
    startRef.current = Date.now();
    intervalRef.current = window.setInterval(() => {
      const elapsed = Date.now() - startRef.current;
      const pct = Math.min(100, (elapsed / HOLD_MS) * 100);
      setProgress(pct);
      if (pct >= 100) {
        cancelHold();
        handleHeat();
      }
    }, 50);
  };

  return (
    <button
      onMouseDown={startHold}
      onMouseUp={cancelHold}
      onMouseLeave={cancelHold}
      onTouchStart={startHold}
      onTouchEnd={cancelHold}
      className="relative px-4 py-2 border border-red-500/40 rounded-lg font-mono text-xs uppercase tracking-widest text-red-400 hover:bg-red-950/30 overflow-hidden select-none"
      title="Press and hold to burn state"
    >
      <div className="absolute inset-0 bg-red-500/20" style={{ width: `${progress}%` }} />
      <span className="relative">{isHolding ? 'HOLDING…' : 'HEAT'}</span>
    </button>
  );
}
