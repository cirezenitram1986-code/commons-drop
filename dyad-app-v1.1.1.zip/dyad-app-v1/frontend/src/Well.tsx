import { useState, KeyboardEvent } from 'react';
import { useDyad } from './DyadContext';

export function Well() {
  const [text, setText] = useState('');
  const { handleSend, state, dispatch } = useDyad();
  const isHighDensity = state.wireframe?.is_high_density ?? false;

  const cycleMode = () => {
    if (!state.modeOverride) dispatch({ type: 'SET_MODE_OVERRIDE', mode: 'DEEP' });
    else if (state.modeOverride === 'DEEP') dispatch({ type: 'SET_MODE_OVERRIDE', mode: 'TACTICAL' });
    else if (state.modeOverride === 'TACTICAL') dispatch({ type: 'SET_MODE_OVERRIDE', mode: 'AUTO' });
    else dispatch({ type: 'SET_MODE_OVERRIDE', mode: null });
  };

  const submit = () => {
    if (!text.trim() || state.isLoading) return;
    handleSend(text.trim());
    setText('');
  };

  const handleKey = (e: KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); }
  };

  const modeLabel = state.modeOverride === 'AUTO' ? 'AUTO' : (state.modeOverride || 'AUTO');
  const isManual = state.modeOverride && state.modeOverride !== 'AUTO';
  const modeColor = isManual ? 'text-amber-400 border-amber-400/30' : 'text-zinc-500 border-zinc-700';

  return (
    <div className="border-t border-zinc-800 p-4 bg-zinc-950">
      {isHighDensity && (
        <div className="mb-2 text-xs text-amber-500 font-mono flex items-center gap-2">
          <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></span>
          Density threshold breached. Enforcer active.
        </div>
      )}
      <div className="flex gap-3 items-end">
        <textarea value={text} onChange={(e) => setText(e.target.value)} onKeyDown={handleKey} placeholder="Speak to the node..." disabled={state.isLoading} rows={1} className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600 resize-none transition-colors disabled:opacity-50" />
        <button onClick={cycleMode} className={`px-3 py-3 border rounded-lg font-mono text-xs uppercase tracking-wider transition-colors ${modeColor} hover:bg-zinc-900`} title="Cycle mode override">{modeLabel}</button>
        <button onClick={submit} disabled={state.isLoading || !text.trim()} className="px-5 py-3 bg-zinc-100 text-zinc-900 font-medium rounded-lg hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors">Send</button>
      </div>
    </div>
  );
}
