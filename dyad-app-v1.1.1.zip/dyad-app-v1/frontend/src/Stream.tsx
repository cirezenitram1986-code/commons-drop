import { useState } from 'react';
import { useDyad } from './DyadContext';
import { StreamMessage } from './types';

function GracePrompt({ proposal, turnIndex }: { proposal: { content: string }, turnIndex: number }) {
  const { handleConfirmGrace } = useDyad();
  const [discarded, setDiscarded] = useState(false);
  if (discarded) return null;

  return (
    <div className="mt-2 p-3 border border-teal-500/20 bg-teal-950/10 rounded-lg text-xs font-mono text-teal-300/80 flex flex-col gap-2">
      <div className="italic">"The node flagged a moment — Keep or Discard?"</div>
      <div className="text-teal-200/60 text-[11px] border-l border-teal-500/30 pl-2">{proposal.content}</div>
      <div className="flex gap-3 mt-1">
        <button onClick={() => handleConfirmGrace(turnIndex, proposal.content, "Model proposed during turn", "model_proposed_human_confirmed")} className="text-teal-400 hover:text-teal-300 underline underline-offset-2">Keep</button>
        <button onClick={() => setDiscarded(true)} className="text-zinc-500 hover:text-zinc-400">Discard</button>
      </div>
    </div>
  );
}

function MessageBubble({ msg }: { msg: StreamMessage }) {
  if (msg.role === 'heat-divider') {
    return (
      <div className="my-8 flex items-center gap-4">
        <div className="flex-1 h-px bg-red-500/50"></div>
        <div className="text-red-500 font-mono text-xs font-bold tracking-widest">{msg.text}</div>
        <div className="flex-1 h-px bg-red-500/50"></div>
      </div>
    );
  }
  if (msg.role === 'system') {
    const color = msg.is_dropped ? 'text-amber-500 border-amber-500/30' : 'text-red-500 border-red-500/30';
    return <div className={`my-4 px-4 py-2 border-l-2 ${color} bg-black/20 text-sm font-mono italic`}>{msg.text}</div>;
  }

  const isUser = msg.role === 'user';
  return (
    <div className={`my-4 flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[80%] ${isUser ? 'order-2' : 'order-1'}`}>
        {!isUser && msg.delta_seconds !== undefined && <div className="text-xs text-zinc-500 mb-1 font-mono">+{msg.delta_seconds}s</div>}
        <div className={`px-4 py-3 rounded-lg whitespace-pre-wrap ${isUser ? 'bg-zinc-800 text-zinc-100' : 'bg-zinc-900 text-zinc-300 border border-zinc-800'} ${msg.is_optimistic ? 'opacity-60' : ''}`}>{msg.text}</div>
        {!isUser && msg.grace_proposed && <GracePrompt proposal={msg.grace_proposed} turnIndex={msg.grace_proposed.turn_index} />}
      </div>
    </div>
  );
}

export function Stream() {
  const { state } = useDyad();
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-2">
      {state.messages.length === 0 && (
        <div className="text-center text-zinc-600 mt-20 font-mono text-sm">
          <p>The wireframe is empty.</p>
          <p className="mt-2">Speak to initialize the structural truth.</p>
        </div>
      )}
      {state.messages.map((msg) => <MessageBubble key={msg.id} msg={msg} />)}
      {state.isLoading && (
        <div className="flex justify-start my-4">
          <div className="px-4 py-3 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-500 animate-pulse">Processing...</div>
        </div>
      )}
    </div>
  );
}
