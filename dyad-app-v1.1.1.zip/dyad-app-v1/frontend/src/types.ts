export interface GraceEntry {
  entry_id: string; turn_index: number; at: string; content: string;
  context: string; marked_by: string; status: string;
}
export interface WireframeSnapshot {
  generation: number; turn_index: number; mode: string; is_high_density: boolean;
  mode_override: { active: boolean; overridden_from: string | null; override_count: number };
  structural_truth: { version: number; text: string; established_at: string }[];
  open_threads: { id: string; label: string; status: string }[];
  friction_log: { entry_id: string; trigger: string; resolution: string; status: string }[];
  grace_log: GraceEntry[];
  state_density: { calculated_score: number };
}
export interface Payload1Payload { text: string; mode_override?: string | null; }
export interface Payload1 {
  session_id: string; user_id: string; client_sent_at: string;
  client_request_id: string; expected_generation: number; payload: Payload1Payload;
}
export interface Payload4 {
  message_id: string; backend_processed_at: string; dropped: boolean;
  payload: {
    rendered_text: string; delta_seconds: number; mode_tag: string;
    grace_proposed?: { content: string; turn_index: number } | null;
    state_ui: { is_high_density: boolean; calculated_score: number };
    wireframe_snapshot?: WireframeSnapshot;
    current_generation?: number;
  };
}
export interface StreamMessage {
  id: string; role: 'user' | 'assistant' | 'system' | 'heat-divider';
  text: string; timestamp?: string; delta_seconds?: number;
  is_optimistic?: boolean; is_dropped?: boolean; is_failed?: boolean;
  grace_proposed?: { content: string; turn_index: number } | null;
}
