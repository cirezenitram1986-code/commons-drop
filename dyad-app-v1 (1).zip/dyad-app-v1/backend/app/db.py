import sqlite3
import json
from contextlib import contextmanager
from .models import Wireframe

DB_PATH = "dyad_state.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def atomic_transaction(db):
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise


def init_db():
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS wireframes (
            session_id TEXT PRIMARY KEY,
            state_json TEXT
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS wireframe_archive (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            archived_at TEXT,
            entry_type TEXT,
            entry_json TEXT
        )
    """)
    db.commit()
    db.close()


def load_wireframe(db, session_id: str) -> Wireframe:
    row = db.execute(
        "SELECT state_json FROM wireframes WHERE session_id=?", (session_id,)
    ).fetchone()
    if row:
        return Wireframe.model_validate(json.loads(row["state_json"]))
    return Wireframe(session_id=session_id)


def save_wireframe(db, wf: Wireframe):
    db.execute(
        "INSERT OR REPLACE INTO wireframes (session_id, state_json) VALUES (?, ?)",
        (wf.session_id, wf.model_dump_json()),
    )
