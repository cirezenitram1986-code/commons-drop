from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .api import router
from .db import init_db

app = FastAPI(title="Dyad App v1")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)
app.include_router(router)


@app.on_event("startup")
def startup():
    init_db()
