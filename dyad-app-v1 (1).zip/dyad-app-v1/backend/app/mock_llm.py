import re


def parse_llm_output(raw_text: str) -> dict:
    tags = {}
    for tag in ["deliberation", "final_render", "state_summary", "wireframe_update"]:
        match = re.search(rf"<{tag}>(.*?)</{tag}>", raw_text, re.DOTALL)
        if match:
            tags[tag] = match.group(1).strip()

    if "deliberation" in tags:
        mode_match = re.search(r"<mode>(.*?)</mode>", tags["deliberation"])
        if mode_match:
            tags["mode"] = mode_match.group(1).strip()

        grace_match = re.search(r"<grace>(.*?)</grace>", tags["deliberation"], re.DOTALL)
        if grace_match:
            tags["grace"] = grace_match.group(1).strip()

    return tags
