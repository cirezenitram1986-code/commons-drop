"""End-to-end verification through the real HTTP layer (separate DB connections
per request, like production). This is the test that catches the /turn commit bug
the single-connection unit tests mask."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import app.db as db_module

db_module.DB_PATH = "verify_dyad_state.db"
if os.path.exists("verify_dyad_state.db"):
    os.remove("verify_dyad_state.db")

from app.db import init_db, get_db, load_wireframe  # noqa: E402
from app.main import app  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

init_db()
client = TestClient(app)
SID = "e2e-session"
passed = []


def check(name, cond):
    assert cond, f"FAILED: {name}"
    passed.append(name)
    print(f"  ok: {name}")


print("1. Turn persists across connections (the commit-bug regression test)")
r = client.post("/turn", json={
    "session_id": SID, "user_id": "u1", "client_sent_at": "now",
    "expected_generation": 0, "payload": {"text": "Hello node"},
})
check("turn accepted", r.status_code == 200 and r.json()["dropped"] is False)
# Fresh connection, like a second request would get:
db2 = get_db()
wf = load_wireframe(db2, SID)
db2.close()
check("turn_index persisted (=1) across connections", wf.turn_index == 1)
check("snapshot carries state_density (frontend contract)", True)  # checked below

print("2. Snapshot contract matches the frontend")
snap = r.json()["payload"]["wireframe_snapshot"]
check("is_high_density present", "is_high_density" in snap)
check("state_density.calculated_score present", snap.get("state_density", {}).get("calculated_score") == 1)

print("3. Generation mismatch drops the turn")
r = client.post("/turn", json={
    "session_id": SID, "user_id": "u1", "client_sent_at": "now",
    "expected_generation": 99, "payload": {"text": "stale"},
})
check("stale turn dropped", r.json()["dropped"] is True)
check("current generation returned", r.json()["payload"]["current_generation"] == 0)

print("4. Grace log round-trip")
r = client.post("/grace", json={
    "session_id": SID, "turn_index": 1, "content": "The unplanned thing",
    "context": "verification", "marked_by": "human",
})
check("grace logged", r.json()["status"] == "logged")
eid = r.json()["entry_id"]
r = client.post("/turn", json={
    "session_id": SID, "user_id": "u1", "client_sent_at": "now",
    "expected_generation": 0, "payload": {"text": "second turn"},
})
snap = r.json()["payload"]["wireframe_snapshot"]
check("grace entry visible in snapshot", any(g["entry_id"] == eid for g in snap["grace_log"]))
r = client.post("/grace/status", json={"session_id": SID, "entry_id": eid, "status": "INTEGRATED"})
check("grace status update accepted", r.json()["status"] == "updated")

print("5. Prune exempts grace, archives friction")
from app.state_machine import execute_prune  # noqa: E402
from app.models import FrictionEntry, GraceEntry  # noqa: E402
db3 = get_db()
wf = load_wireframe(db3, SID)
wf.friction_log.append(FrictionEntry(turn_index=1, at="now", trigger="t", resolution="r"))
from app.db import save_wireframe  # noqa: E402
save_wireframe(db3, wf)
db3.commit()
db3.close()
db4 = get_db()
wf = load_wireframe(db4, SID)
execute_prune(db4, wf, "summary of all pruned state")
db4.commit()
n_friction_archived = db4.execute(
    "SELECT COUNT(*) FROM wireframe_archive WHERE entry_type='friction_pruned'"
).fetchone()[0]
check("friction archived before prune", n_friction_archived == 1)
wf2 = load_wireframe(db4, SID)
db4.close()
check("friction cleared by prune", len(wf2.friction_log) == 0)
check("grace survived the prune", len(wf2.grace_log) == 1)
check("grace status intact", wf2.grace_log[0].status == "INTEGRATED")

print("6. HEAT burns state, bumps generation, keeps forensic snapshot")
r = client.post("/heat", json={"session_id": SID, "trigger": "test"})
check("heat returned generation 1", r.json()["generation"] == 1)
db5 = get_db()
n_heat = db5.execute(
    "SELECT COUNT(*) FROM wireframe_archive WHERE entry_type='heat_snapshot'"
).fetchone()[0]
check("forensic snapshot archived", n_heat == 1)
wf3 = load_wireframe(db5, SID)
db5.close()
check("state burned (turn_index reset)", wf3.turn_index == 0)
check("grace_log survives HEAT (exempt by design)", len(wf3.grace_log) == 1)

print("7. Dispute flips friction status")
db6 = get_db()
wf = load_wireframe(db6, SID)
wf.friction_log.append(FrictionEntry(entry_id="f1", turn_index=1, at="now", trigger="t", resolution="r"))
save_wireframe(db6, wf)
db6.commit()
db6.close()
r = client.post("/dispute", json={"session_id": SID, "friction_id": "f1"})
check("dispute accepted", r.json()["status"] == "disputed")
db7 = get_db()
wf4 = load_wireframe(db7, SID)
db7.close()
check("friction marked DISPUTED", wf4.friction_log[0].status == "DISPUTED")

print(f"\nALL {len(passed)} E2E CHECKS PASSED")
os.remove("verify_dyad_state.db")
