import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { StreamMessage, WireframeSnapshot, Payload4, GraceEntry } from './types';
import { sendTurn, sendHeat, sendDispute, sendRollback, sendGrace, updateGraceStatus } from './api';

interface State {
  sessionId: string; userId: string; messages: StreamMessage[];
  wireframe: WireframeSnapshot | null; generation: number;
  isLoading: boolean; isDrawerOpen: boolean; modeOverride: string | null;
}
type Action =
  | { type: 'SEND_OPTIMISTIC'; id: string; text: string }
  | { type: 'RESOLVE_SUCCESS'; id: string; p4: Payload4 }
  | { type: 'RESOLVE_DROPPED'; id: string; newGen: number }
  | { type: 'RESOLVE_FAILURE'; id: string; error: string }
  | { type: 'HEAT_SUCCESS'; generation: number }
  | { type: 'DISPUTE_SUCCESS'; frictionId: string }
  | { type: 'ROLLBACK_SUCCESS'; generation: number; target_version: number }
  | { type: 'CONFIRM_GRACE'; entry: GraceEntry }
  | { type: 'UPDATE_GRACE_STATUS'; entryId: string; status: string }
  | { type: 'TOGGLE_DRAWER' }
  | { type: 'SET_MODE_OVERRIDE'; mode: string | null };

const initialState: State = {
  sessionId: 'default-session', userId: 'default-user', messages: [],
  wireframe: null, generation: 0, isLoading: false, isDrawerOpen: false, modeOverride: null,
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'SEND_OPTIMISTIC':
      return { ...state, isLoading: true, messages: [...state.messages, { id: action.id, role: 'user', text: action.text, is_optimistic: true }] };
    case 'RESOLVE_DROPPED':
      return { ...state, isLoading: false, generation: action.newGen, messages: [...state.messages, { id: action.id, role: 'system', text: `[Turn dropped: Generation mismatch. Resynced to ${action.newGen}.]`, is_dropped: true }] };
    case 'RESOLVE_SUCCESS': {
      const { p4, id } = action;
      if (p4.dropped) return state; // Handled by RESOLVE_DROPPED
      const assistantMsg: StreamMessage = {
        id, role: 'assistant', text: p4.payload.rendered_text,
        delta_seconds: p4.payload.delta_seconds, timestamp: p4.backend_processed_at,
        grace_proposed: p4.payload.grace_proposed || null,
      };
      return { ...state, isLoading: false, messages: [...state.messages, assistantMsg], wireframe: p4.payload.wireframe_snapshot || state.wireframe, generation: p4.payload.wireframe_snapshot?.generation ?? state.generation };
    }
    case 'RESOLVE_FAILURE':
      return { ...state, isLoading: false, messages: [...state.messages, { id: action.id, role: 'system', text: `[Network failure: ${action.error}]`, is_failed: true }] };
    case 'HEAT_SUCCESS':
      return { ...state, isLoading: false, generation: action.generation, wireframe: null, messages: [...state.messages, { id: crypto.randomUUID(), role: 'heat-divider', text: `HEAT EXECUTED. GENERATION ${action.generation}. STATE BURNED.` }] };
    case 'DISPUTE_SUCCESS': {
      if (!state.wireframe) return state;
      const updatedFriction = state.wireframe.friction_log.map(f => f.entry_id === action.frictionId ? { ...f, status: 'DISPUTED' } : f);
      return { ...state, wireframe: { ...state.wireframe, friction_log: updatedFriction } };
    }
    case 'ROLLBACK_SUCCESS':
      return { ...state, isLoading: false, generation: action.generation, wireframe: null, messages: [...state.messages, { id: crypto.randomUUID(), role: 'system', text: `[Truth rolled back to version ${action.target_version}. Generation bumped to ${action.generation}.]` }] };
    case 'CONFIRM_GRACE': {
      if (!state.wireframe) return state;
      return { ...state, wireframe: { ...state.wireframe, grace_log: [...state.wireframe.grace_log, action.entry] } };
    }
    case 'UPDATE_GRACE_STATUS': {
      if (!state.wireframe) return state;
      const updatedLog = state.wireframe.grace_log.map(g => g.entry_id === action.entryId ? { ...g, status: action.status } : g);
      return { ...state, wireframe: { ...state.wireframe, grace_log: updatedLog } };
    }
    case 'TOGGLE_DRAWER': return { ...state, isDrawerOpen: !state.isDrawerOpen };
    case 'SET_MODE_OVERRIDE': return { ...state, modeOverride: action.mode };
    default: return state;
  }
}

const DyadContext = createContext<{
  state: State; dispatch: React.Dispatch<Action>;
  handleSend: (text: string) => void; handleHeat: () => void;
  handleDispute: (frictionId: string) => void; handleRollback: (version: number) => void;
  handleConfirmGrace: (turnIndex: number, content: string, context: string, markedBy: string) => void;
  handleUpdateGraceStatus: (entryId: string, status: string) => void;
} | null>(null);

export function DyadProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const handleSend = async (text: string) => {
    const reqId = crypto.randomUUID();
    dispatch({ type: 'SEND_OPTIMISTIC', id: reqId, text });
    const attemptSend = async (gen: number, isRetry: boolean) => {
      try {
        const p4 = await sendTurn(state.sessionId, state.userId, text, gen, state.modeOverride);
        if (p4.dropped && !isRetry) {
          const newGen = p4.payload.current_generation ?? gen;
          dispatch({ type: 'RESOLVE_DROPPED', id: crypto.randomUUID(), newGen });
          await attemptSend(newGen, true);
          return;
        }
        const replyId = isRetry ? `${reqId}-retry-reply` : `${reqId}-reply`;
        dispatch({ type: 'RESOLVE_SUCCESS', id: replyId, p4 });
      } catch (e: any) {
        dispatch({ type: 'RESOLVE_FAILURE', id: crypto.randomUUID(), error: e.message });
      }
    };
    await attemptSend(state.generation, false);
  };

  const handleHeat = async () => { try { const res = await sendHeat(state.sessionId); dispatch({ type: 'HEAT_SUCCESS', generation: res.generation }); } catch (e: any) { dispatch({ type: 'RESOLVE_FAILURE', id: crypto.randomUUID(), error: e.message }); } };
  const handleDispute = async (frictionId: string) => { try { await sendDispute(state.sessionId, frictionId); dispatch({ type: 'DISPUTE_SUCCESS', frictionId }); } catch (e) { console.error(e); } };
  const handleRollback = async (version: number) => { try { const res = await sendRollback(state.sessionId, version); dispatch({ type: 'ROLLBACK_SUCCESS', generation: res.generation, target_version: version }); } catch (e: any) { dispatch({ type: 'RESOLVE_FAILURE', id: crypto.randomUUID(), error: e.message }); } };

  const handleConfirmGrace = async (turnIndex: number, content: string, context: string, markedBy: string) => {
    try {
      const res = await sendGrace(state.sessionId, turnIndex, content, context, markedBy);
      const newEntry: GraceEntry = { entry_id: res.entry_id, turn_index: turnIndex, at: new Date().toISOString(), content, context, marked_by: markedBy, status: 'ACTIVE' };
      dispatch({ type: 'CONFIRM_GRACE', entry: newEntry });
    } catch (e) { console.error(e); }
  };

  const handleUpdateGraceStatus = async (entryId: string, status: string) => {
    try { await updateGraceStatus(state.sessionId, entryId, status); dispatch({ type: 'UPDATE_GRACE_STATUS', entryId, status }); } catch (e) { console.error(e); }
  };

  return (
    <DyadContext.Provider value={{ state, dispatch, handleSend, handleHeat, handleDispute, handleRollback, handleConfirmGrace, handleUpdateGraceStatus }}>
      {children}
    </DyadContext.Provider>
  );
}

export const useDyad = () => {
  const ctx = useContext(DyadContext);
  if (!ctx) throw new Error('useDyad must be used within DyadProvider');
  return ctx;
};
