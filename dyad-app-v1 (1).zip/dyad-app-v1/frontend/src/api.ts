import { Payload1, Payload4 } from './types';
const API_BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';

async function fetchWithTimeout(url: string, options: RequestInit, timeout = 120000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(id); }
}

export async function sendTurn(sessionId: string, userId: string, text: string, expectedGeneration: number, modeOverride?: string | null): Promise<Payload4> {
  const payload1: Payload1 = {
    session_id: sessionId, user_id: userId, client_sent_at: new Date().toISOString(),
    client_request_id: crypto.randomUUID(), expected_generation: expectedGeneration,
    payload: { text, mode_override: modeOverride || null },
  };
  const res = await fetchWithTimeout(`${API_BASE}/turn`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload1) });
  if (!res.ok) throw new Error(`Backend returned ${res.status}`);
  return res.json();
}

export const sendHeat = (sid: string) => fetchWithTimeout(`${API_BASE}/heat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: sid }) }).then(r => r.json());
export const sendDispute = (sid: string, fid: string) => fetchWithTimeout(`${API_BASE}/dispute`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: sid, friction_id: fid }) }).then(r => r.json());
export const sendRollback = (sid: string, v: number) => fetchWithTimeout(`${API_BASE}/rollback`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: sid, target_version: v }) }).then(r => r.json());
export const sendGrace = (sid: string, ti: number, c: string, ctx: string, mb: string) => fetchWithTimeout(`${API_BASE}/grace`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: sid, turn_index: ti, content: c, context: ctx, marked_by: mb }) }).then(r => r.json());
export const updateGraceStatus = (sid: string, eid: string, s: string) => fetchWithTimeout(`${API_BASE}/grace/status`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: sid, entry_id: eid, status: s }) }).then(r => r.json());
